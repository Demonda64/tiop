var voiture = {
    type: "citadine",
    couleur: "red",
    
}